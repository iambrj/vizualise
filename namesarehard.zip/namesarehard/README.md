No extra dependencies are required, each visualization can be opened in a web
browser by clicking on the appropriate html file.
